
import View.InitialFrame;
import View.View;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * File name: App.java
 * Short description: runs game
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        View v = new View ();
        // TODO code application logic here
    }
    
}
