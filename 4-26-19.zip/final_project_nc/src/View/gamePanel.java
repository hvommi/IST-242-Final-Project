/**
 * File name: gamePanel.java
 * Short description: creates "initial panel" for the game
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.Timer;
import javax.imageio.ImageIO;

/**
 *
 * @author hvomm
 */
public class gamePanel extends JPanel implements ActionListener {

    JPanel buttonPanel;
    JButton startB, stopB;
    JLabel score;
    AnimationPane ap;

    InputMap iMap = this.getInputMap(WHEN_IN_FOCUSED_WINDOW);
    ActionMap aMap = this.getActionMap();
    //JPanel scorePanel;
    
    public gamePanel() throws IOException {

       
        //setting layout
        setLayout(new BorderLayout());
        setBackground(Color.blue);


        //initializing and adding button(s): 
        startB = new JButton("Start!  :)");
        startB.addActionListener(this);
    
        add(startB, "North");
        
       

        //adding score text
        score = new JLabel("Score: ");
        add(score, "South");
        score.setForeground(Color.white);
        score.setSize(1000, 1000);
       


      
    }

     //adding animation pane when start is pressed : 
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startB) {
            try {
                if (Arrays.asList(this.getComponents()).contains(ap)) {
                    this.remove(ap);
                }
                ap = new AnimationPane(score);
            } catch (IOException ex) {
                Logger.getLogger(gamePanel.class.getName()).log(Level.SEVERE, null, ex);
            }
            add(ap, "Center");


            ap.setBackground(Color.black);
            ap.setBounds(new Rectangle(0, 0, 1920, 1510));
            repaint();
        }

    }

}

// Set methods - one set method for each instance variable defined above
//             - purpose is to pass in a value stored in the private variable
// Get methods - one get method for each instance variable defined above
//             - purpose is to return the value stored in the private variable
// Additional methods -- such as for calculation, display

