/**
 * File name: View.java
 * Short description: creates view instance
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */
package View;

import java.awt.BorderLayout;
import java.io.IOException;
//import java.io.IOException;






/**
 *
 * @author hvomm
 */
public class View {
        InitialFrame iFrame;

	// Instance Variables -- define your private data


	// Constructors
	public View() throws IOException //throws IOException 
	{
		// initialize default values
            iFrame = new InitialFrame();
            //iFrame.setLayout(new BorderLayout());
            
	}
	 
	// Set methods - one set method for each instance variable defined above
	//             - purpose is to pass in a value stored in the private variable

	// Get methods - one get method for each instance variable defined above
	//             - purpose is to return the value stored in the private variable

	// Additional methods -- such as for calculation, display

	



}
