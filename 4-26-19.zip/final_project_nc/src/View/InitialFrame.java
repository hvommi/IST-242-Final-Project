/**
 * File name: InitialFrame.java
 * Short description: creates "initial frame" for the game
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
//import java.io.IOException;
import java.util.ArrayList;
//import javax.imageio.ImageIO;

import static javax.swing.JFrame.EXIT_ON_CLOSE;


public class InitialFrame extends JFrame {

    private gamePanel gp; //initialzing
  
   

    public InitialFrame() throws IOException {
        super("Nyan Cat");
        setLayout(new BorderLayout());
        gp = new gamePanel(); // initialize and add game panel
        gp.setBackground(Color.blue);
        add(gp);
       
        
      

        setSize(794, 640);
        setVisible(true);

        setResizable(true); //true, but game will not function properly unless full screen :(
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
    }


}
