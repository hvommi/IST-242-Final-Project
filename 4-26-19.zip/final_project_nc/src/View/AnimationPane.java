
/**
 * File name: AnimationPane.java
 * Short description: creates components of the game in a panel
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */

package View;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;







public class AnimationPane extends JPanel {

        
        private BufferedImage cat;
        JLabel poptart1, poptart2;
        private int xPos = 0, yPos = 0;
        private int direction = 5;
        private int points;
        Timer timer;
        JLabel scoreLabel;
     

        public AnimationPane(JLabel sLabel) throws IOException 
        {
            setLayout(null);
           
            //adding poptarts:
            scoreLabel = sLabel;
             BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        
        poptart1 = new JLabel(new ImageIcon(pop1));
        
        BufferedImage pop2 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        poptart2 = new JLabel(new ImageIcon(pop2));
        
        //setting size and location of poptarts: 
        
         poptart1.setBounds(new Rectangle (300, -100, 400, 400));
        poptart2.setBounds(new Rectangle (1000, 800, 400, 400));
        
        //adding poptarts:
         add(poptart1);
         add(poptart2);
        
            //moves cat across screen
               cat = ImageIO.read(new File("images/nyancat.png"));
               
                timer = new Timer(0, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        
                        xPos += direction;
                        if (xPos + cat.getWidth() > getWidth()) {
                            
                            xPos = getWidth() - cat.getWidth();
                            direction *= -1;
                            movePops();
                            points++;
                            sLabel.setText("Points: " + points);
                            
                        } else if (xPos < 0) {
                            movePops();                            
                            xPos = 0;
                            points++;
                            direction *= -1;
                            sLabel.setText("Points: " + points);
                        }
                        repaint();
                    }

                    
                });
                timer.setRepeats(true);
                timer.setCoalesce(true);
                
                timer.start();
            
        }
//repainting methods
        @Override
        public Dimension getPreferredSize() {
            return cat == null ? super.getPreferredSize() : new Dimension(cat.getWidth() * 1, cat.getHeight());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            g.drawImage(cat, xPos, yPos, this);

        }
        
        
        
     //need methods for jumping and falling
     
     public void  movePops(){
         Random r = new Random();
		
                     //sets height randomly for the poptarts

          poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
          
          while (poptart1.getLocation().getY() < -100){
                poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
          }
          
            poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
            
            while (poptart2.getLocation().getY() > 800){
                poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
                
             if (Math.abs(poptart1.getLocation().getY() - poptart2.getLocation().getY()) < 500){
                  poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
              poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
             }
          }
            
          
          
     }
     
    public int getPoints(){
        return points;
    }
    
    //*******needs method for what happens when cat "dies"!
    
   //*****needs method for collision!
}