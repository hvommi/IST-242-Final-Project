/**
 * File name: $({name}.java
 * Short description:
 * IST 242 Assignment:In class
 *
 * @author HIMANI VOMMI
 * @version 1.16.19
 */
package View;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

/**
 *
 * @author hvomm
 */
public class AnimationPane extends JPanel {

    public JLabel score;
    private BufferedImage cat;
    private int xPos = 0;
    private int yPos = getHeight() / 2; //y pos in middle of screen?
    private int direction = 1;
    private int points;
    private gamePanel gp;

    public AnimationPane() {
        System.out.println("constructor called! :o ");

        try {
            cat = ImageIO.read(new File("nyancat.png"));

            Timer timer = new Timer(1, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //score.setText("Points: " + points);
                    System.out.println("moving cat!");
                    System.out.println("Points 1: " + points);

                    xPos += direction;
                    if (xPos + cat.getWidth() > getWidth()) {
                        xPos = getWidth() - cat.getWidth();
                        direction *= -1;

                        points++;
                        score.setText("Points: " + points);
                        System.out.println("right side");
                        // System.out.println("score: " + points);

//                            if (points == 5){
//                                direction *= 1.1;
//                            }
//                            if (points == 10){
//                                direction *= 1.6;
//                            }
//                            if (points == 20){
//                                direction *= 1.8;
//                            }
//                            if (points == 40){
//                                direction *= 2.2;
//                            }
                    } else if (xPos < 0) {
                        xPos = 0;
                        direction *= -1;
                        points++;
                        score.setText("Points: " + points);
//                             if (points == 5){
//                                direction *= -1.1;
//                            }
//                             if (points == 10){
//                                direction *= -1.6;
//                            }
//                             if (points == 20){
//                                direction *= -1.8;
//                            }
//                            if (points == 40){
//                                direction *= -2.2;
//                            }
                        System.out.println("left side");
                        //System.out.println("score: " + points);
                    }
                    repaint();
                }
            });

//             if(points >= 5 && points <= 20 && left) //cap the increasing pace once 20 points scored lol
//                        direction *= 3;
            timer.setRepeats(true);
            timer.setCoalesce(true);

            timer.start();
            score = new JLabel();
            add(score);
            System.out.println("Points 2: " + points);

            //score.setText("Points: " + getPoints());
            score.setForeground(Color.white);
            score.setSize(100, 100);

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    @Override
    public Dimension getPreferredSize() {
        return cat == null ? super.getPreferredSize() : new Dimension(cat.getWidth() * 1, cat.getHeight());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int y = getHeight() - cat.getHeight();
        g.drawImage(cat, xPos, y, this);

    }

    public int getPoints() {
        return points;
    }

    public BufferedImage getCat() {
        return cat;
    }

}
