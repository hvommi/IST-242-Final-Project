/**
 * File name: $({name}.java
 * Short description:
 * IST 242 Assignment:In class
 *
 * @author HIMANI VOMMI
 * @version 1.16.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Timer;
import javax.imageio.ImageIO;

/**
 *
 * @author hvomm
 */
public class gamePanel extends JPanel {
    //NyanCat nc;
    JLabel poptart1, poptart2, nyancat;
    AnimationPane ap;
    JButton startB;
    //int xPos;
     public JLabel score;
    private BufferedImage cat;
    private int xPos = 0;
    private int yPos = getHeight() /2 ; //y pos in middle of screen?
    private int direction = 3;
    private int points;
    // Instance Variables -- define your private data
    // Constructors
    protected Image bgImage;
    private boolean moved = false;
    //JLabel score;

    public gamePanel() throws IOException {
        super();
        setLayout(null);
        //setLayout(new GridLayout(3,1));
        System.out.println("def construct");
        System.out.println("calling nc");
        
        BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        
        poptart1 = new JLabel(new ImageIcon(pop1));
//        {
//        
//        public Dimension getPreferredSize() {
//                return new Dimension(300, 300);
//            }
//        };
       
         BufferedImage pop2 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        poptart2 = new JLabel(new ImageIcon(pop2));
        
        cat = ImageIO.read(new File("nyancat.png"));
        System.out.println("cat image");
        nyancat = new JLabel(new ImageIcon(cat));
        
        score = new JLabel();
        
          add(poptart1);
         add(poptart2);
        add(nyancat); // this makes the cat picture show up
         add(score);
         
         score.setForeground(Color.white);
          score.setText("          Points: " + points);
          score.setBounds(0, 0, 100, 100);
           score.setHorizontalTextPosition(JLabel.CENTER);
           
//           System.out.println("Getting cats width? " + cat.getWidth() ); debugging
//           System.out.println("Getting overall width: " + getWidth());
           
           
      /************************************************************************
            * 
            */
      
            
            points = 0;
            Timer timer = new Timer(1, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                     //score.setText("Points: " + points);
                     System.out.println("moving cat!");
                     System.out.println("Points 1: " + points);
                     
                  
                        xPos += direction;
                        if (xPos + nyancat.getWidth() > 1920) {
                            //xPos = 1920 - nyancat.getWidth();
                            
                            direction *= -1;
                            
                            
                               nyancat.setBounds(new Rectangle(xPos, 300, 400, 400));
                            
                            
                           
                            
                            
                            points++;
                            score.setText("Points: " + points);
                            System.out.println("right side");
                           // System.out.println("score: " + points);
                            //speed manipulation
//                            if (points == 5){
//                                direction *= 1.1;
//                            }
//                            if (points == 10){
//                                direction *= 1.6;
//                            }
//                            if (points == 20){
//                                direction *= 1.8;
//                            }
//                            if (points == 40){
//                                direction *= 2.2;
//                            }
                            
                        } else if (xPos < 0) {
                            xPos = 0;
                            direction *= -1;
                            points++;
                             score.setText("Points: " + points);
                             
                             
                              nyancat.setBounds(new Rectangle(xPos, 300, 400, 400));
                                  //speed manipulation
//                             if (points == 5){
//                                direction *= -1.1;
//                            }
//                             if (points == 10){
//                                direction *= -1.6;
//                            }
//                             if (points == 20){
//                                direction *= -1.8;
//                            }
//                            if (points == 40){
//                                direction *= -2.2;
//                            }
                                System.out.println("left side");
                                 //System.out.println("score: " + points);
                        }
                        repaint();
                    }
            });
            
//             if(points >= 5 && points <= 20 && left) //cap the increasing pace once 20 points scored lol
//                        direction *= 3;
             
             
            timer.setRepeats(true);
            timer.setCoalesce(true);
            
            timer.start();
            //score = new JLabel();
            //add(score);
            System.out.println("Points 2: " + points);
           
            //score.setText("Points: " + getPoints());
//            score.setForeground(Color.white);
//            score.setSize(100, 100);
//            
            
       //**********************************************************************
        
//        startB = new JButton("Play!");
//        add(startB);
        
        //System.out.println("trying to add to label");
        
       //poptart1.setLocation(0, 0);
        
        
        
//        ap = new AnimationPane();
//        ap.setBackground(Color.blue);
//       
//        //add(ap);
//        ap.setBounds(0, 400, 1920, 300);
         score.setText("          Points: " + points);
        //setting initial locations and sizes: 
        poptart1.setBounds(new Rectangle (850, 0, 300, 300));
        poptart2.setBounds(new Rectangle (850, 700, 300, 300));
        nyancat.setBounds(new Rectangle(0, 300, 450, 450));
        
       
           // moved = xMove(100);
        
        
//        {public Dimension getPreferredSize() {
//                return new Dimension(700, 700);
//            }
//        };
       
        System.out.println("trying to add to label");
        //System.out.println("width " + getWidth());
         
//        score = new JLabel("Points");
//        add(score);
//        score.setText("Points: " + ap.getPoints());
//        BufferedImage cat = ImageIO.read(new File("images/nyancat.png"));
//        System.out.println("new image?");
//        c = new JLabel(new ImageIcon(cat)){
//        public Dimension getPreferredSize() {
//                return new Dimension(1000, 1000);
//            }
//        };
//        System.out.println("trying to add to label");
//         add(c);
//         Point point = c.getLocation();
         
//         for (int i = 0; i < 5; i++){
//             point.x += 400;
//             System.out.println(point.x);
//             c.setLocation(point);
//             repaint();
//             //point.y += yDelta;
//         }

        //while (false)
//        System.out.println("Points from ap: " + ap.getPoints());
       score.setText("          Points : " + points); 
        
        
        
        
        
        
        
    }   
    //int n is distance to move horizontally; changes for difficulty to imitate speed
//     public boolean xMove (int n){
//           System.out.println("called move");
//           System.out.println("xPos" + xPos);
//                    xPos += n;
//            Timer timer = new Timer(1, new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                    
//                    System.out.println("new xPos " + (xPos + n));
//                     nyancat.setBounds(new Rectangle(xPos + n, 300, 450, 450));
//                      }
//                    
//            });
//            System.out.println("xPos after listener " + xPos);
//            
//            if (xPos < 1920) return false;
//            else return true;          
//            
//     }
                    
                    
                   
//                        xPos += direction;
//                        if (xPos + cat.getWidth() > 1920) {
//                            xPos = 1920 - nyancat.getWidth();
//                            direction *= -1;
//                            points++;
//                            score.setText("Points: " + points);
//                            
////                            if (points == 5){
////                                direction *= 1.1;
////                            }
//                            if (points == 10){
//                                direction *= 1.6;
//                            }
//                            if (points == 20){
//                                direction *= 1.8;
//                            }
//                            if (points == 40){
//                                direction *= 2.2;
//                            }
//                            
//                        } else if (xPos < 0) {
//                            xPos = 0;
//                            direction *= -1;
//                            points++;
//                             score.setText("Points: " + points);
////                             if (points == 5){
////                                direction *= -1.1;
////                            }
//                             if (points == 10){
//                                direction *= -1.6;
//                            }
//                             if (points == 20){
//                                direction *= -1.8;
//                            }
//                            if (points == 40){
//                                direction *= -2.2;
//                            }
//                             
//                        }
//                        repaint();

                   
     

    public JLabel getPoptart1() {
        return poptart1;
    }

    public JLabel getPoptart2() {
        return poptart2;
    }

//    public JLabel getCat() {
//        return c;
//    }

    public JButton getStartB() {
        return startB;
    }
    
    
    

    public gamePanel(Image image) {
        super(true);
        bgImage = image;
        setOpaque(true);
    }

    public void paint(Graphics g) {
        g.drawImage(bgImage, 0, 0, this);
        super.paint(g);
    }
    
    
    
//	public gamePanel()
//	{
//		 super();
     
//        
//        setBackground(Color.cyan); //background color
//        
//        System.out.println("Construct Initial Panel");
//         

    public void setScore(int n) {
        points = n;
        System.out.println("Points after setScore: " + n);
        score.setText("          Points: " + points);  
    }
}

// Set methods - one set method for each instance variable defined above
//             - purpose is to pass in a value stored in the private variable
// Get methods - one get method for each instance variable defined above
//             - purpose is to return the value stored in the private variable
// Additional methods -- such as for calculation, display





