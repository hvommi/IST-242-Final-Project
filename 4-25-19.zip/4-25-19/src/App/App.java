/**
	File name: App.java
	Short description:runs the program
	IST 242 Assignment:L04D
	@author HIMANI VOMMI
	@version 3.31.19
*/
//import Model.Model;
package App;
import View.View;
import java.io.IOException;
//import Controller.Controller;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
//import View.NyanCat;
import View.Controller;

public class App
{
 /**
	 * Main executable method invoked when running .jar file
	 * @param args
	 */
  
        //global variables
	//global swing objects
	//private JFrame f = new JFrame("Nyan Cat Game");
	
	//other global objects
	
	public static void main(String[] args) {
            try {
                //build the GUI on a new thread
                View view = new View ();
                //NyanCat n = new NyanCat(100, 100);
                Controller c = new Controller(view);
//		javax.swing.SwingUtilities.invokeLater(new Runnable() {
//			public void run() {
//				tc.buildFrame();
//				//create a new thread to keep the GUI responsive while the game runs
//				Thread t = new Thread() {
//					public void run() {
//						//in here we will call a function to start the game
//					}
//				};
//				t.start();
//			}
//		});
            } catch (IOException ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
	}
}


