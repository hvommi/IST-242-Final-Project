/**
 * File name: $({name}.java
 * Short description:
 * IST 242 Assignment:In class
 *
 * @author HIMANI VOMMI
 * @version 1.16.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author hvomm
 */
public class InitialFrame extends JFrame {

    private gamePanel gp;
    private int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
    private int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

    public InitialFrame() throws IOException {
        super("Nyan Cat");

        //Image icon = Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("images/nyancat.png"));
        JPanel gamePanel = new gamePanel();
        
        gamePanel.setBackground(Color.blue);
        add(gamePanel);
//        BufferedImage myPicture = ImageIO.read(new File("images/space.gif"));
//        System.out.println("new image?");
//        JLabel bckgdLabel = new JLabel(new ImageIcon(myPicture)) {
//            @Override
//            public Dimension getPreferredSize() {
//                return new Dimension(1500, 1500);
//            }
//        ;
//        };
                
                
                
                ;
        // bckgdLabel.setBounds(40, 30, 700, 300);
        //SetImageSize(12);
        System.out.println("trying to add to label");

        //gamePanel.add(bckgdLabel);

//        BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
//        System.out.println("new image?");
//        JLabel poptart1 = new JLabel(new ImageIcon(pop1)){
//        public Dimension getPreferredSize() {
//                return new Dimension(300, 300);
//            }
//        };
//        System.out.println("trying to add to label");
//         gamePanel.add(poptart1);
//        add(gamePanel);
//        
//        BufferedImage pop2 = ImageIO.read(new File("images/poptart.png"));
//        System.out.println("new image?");
//        JLabel poptart2 = new JLabel(new ImageIcon(pop2)){
//        public Dimension getPreferredSize() {
//                return new Dimension(700, 700);
//            }
//        };
//        System.out.println("trying to add to label");
//         gamePanel.add(poptart2);
//        add(gamePanel);
//        
//        BufferedImage cat = ImageIO.read(new File("images/nyancat.png"));
//        System.out.println("new image?");
//        JLabel c = new JLabel(new ImageIcon(cat)){
//        public Dimension getPreferredSize() {
//                return new Dimension(1000, 1000);
//            }
//        };
//        System.out.println("trying to add to label");
//         gamePanel.add(c);
//        add(gamePanel);
//    Image img = Toolkit.getDefaultToolkit().getImage("images/stars.PNG");
//    
//    JPanel gamePanel = new gamePanel();
//    gamePanel.setLayout( new FlowLayout() );
//    add(gamePanel);

        setSize(794, 640);
        setVisible(true);

        setResizable(true); //true, but game will not function properly unless maximized!
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setAlwaysOnTop(false);
        setVisible(true);
        setMinimumSize(new Dimension(SCREEN_WIDTH * 1 / 4, SCREEN_HEIGHT * 1 / 4)); //set to prevent collapse to tiny window upon resizing
        setExtendedState(JFrame.MAXIMIZED_BOTH); //maximize the JFrame
        //setIconImage(icon); //set the icon
    }

    public gamePanel getGp() {
        return gp;
    }

//    public void SetImageSize(int i) {
//        ImageIcon icon = new ImageIcon(list[i]);
//        Image img = icon.getImage();
//        Image newImg = img.getScaledInstance(pic.getWidth(), pic.getHeight(), img.SCALE_SMOOTH);
//        ImageIcon newImc = new ImageIcon(newImg);
//        pic.setIcon(newImc);
//    }
}
