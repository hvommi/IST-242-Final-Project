
/**
	File name: $({name}.java
	Short description:
	IST 242 Assignment:In class
	@author HIMANI VOMMI
	@version 1.16.19 
*/

package View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import javax.swing.JLabel;

/**
 *
 * @author hvomm
 */
public class Controller implements KeyListener{

	// Instance Variables -- define your private data
        gamePanel gp;
        AnimationPane ap;
        //JLabel c;


	// Constructors
	public Controller(View v) throws IOException
	{
            gp = new gamePanel();
            //c = gp.getCat();
            
            
		// initialize default values
	}

     
    
    public void jump (){
//        if (ap.getLocation().y < gp.getHeight())
//        ap.setLocation(ap.getLocation().x, ap.getLocation().y + 200); //moves up 200 if the location isn't already at the top
    }

    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("typed");
        jump();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("pressed");
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("released");
    }
}
