/**
	File name: App.java
	Short description:runs the program
	IST 242 Assignment:L04D
	@author HIMANI VOMMI
	@version 3.31.19
*/
//import Model.Model;
package App;
import View.View;
import java.io.IOException;
//import Controller.Controller;

public class App
{
 public static void main(String[] args) throws IOException
 {
  View view = new View();
//  Model model = new Model();
//  Controller controller = new Controller(model, view);
 }
}


/* output:

=============================================================
[name, height, weight, hometown, highSchool, number, position]
=============================================================
[Jack Haffner, 5'10", 218, State College, Pa., State College Area, 32, LB]
=============================================================
[Marcus Allen, 6'2", 209, Upper Marlboro, Md., Dr. Henry A. Wise, Jr., 2, S]
[Kyle Alston, 5'9", 180, Robbinsville, N.J., Robbinsville, 37, CB]
[Troy Apke, 6'1", 198, Mt. Lebanon, Pa., Mount Lebanon, 28, S]
[Matthew Baney, 6'0", 225, State College, Pa., State College, 35, LB]
[Saquon Barkley, 5'11", 222, Coplay, Pa., Whitehall, 26, RB]
=============================================================
BUILD SUCCESSFUL (total time: 0 seconds)

*/