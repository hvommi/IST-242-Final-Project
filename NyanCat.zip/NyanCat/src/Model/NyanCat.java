
/**
	File name: $({name}.java
	Short description:
	IST 242 Assignment:In class
	@author HIMANI VOMMI
	@version 1.16.19 
*/

package Model;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

import static javax.swing.JFrame.EXIT_ON_CLOSE;






/**
 *
 * @author hvomm
 */
public class NyanCat {


	// Instance Variables -- define your private data
    


	// Constructors
	public NyanCat()
	{
		// initialize default values
	}
	public NyanCat(int data) // pass in data to initialize variables
	{
	}

	// Set methods - one set method for each instance variable defined above
	//             - purpose is to pass in a value stored in the private variable

	// Get methods - one get method for each instance variable defined above
	//             - purpose is to return the value stored in the private variable

	// Additional methods -- such as for calculation, display

	public String toString()
	{
		// return data as a String
		return "";
	}




}
