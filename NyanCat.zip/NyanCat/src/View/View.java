
/**
	File name: $({name}.java
	Short description:
	IST 242 Assignment:In class
	@author HIMANI VOMMI
	@version 1.16.19 
*/

package View;

import java.awt.BorderLayout;
import java.io.IOException;






/**
 *
 * @author hvomm
 */
public class View {
        InitialFrame iFrame;

	// Instance Variables -- define your private data


	// Constructors
	public View() throws IOException 
	{
		// initialize default values
            iFrame = new InitialFrame();
            //iFrame.setLayout(new BorderLayout());
            
	}
	 
	// Set methods - one set method for each instance variable defined above
	//             - purpose is to pass in a value stored in the private variable

	// Get methods - one get method for each instance variable defined above
	//             - purpose is to return the value stored in the private variable

	// Additional methods -- such as for calculation, display

	public String toString()
	{
		// return data as a String
		return "";
	}




}
