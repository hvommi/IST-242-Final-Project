/**
 * File name: $({name}.java
 * Short description:
 * IST 242 Assignment:In class
 *
 * @author HIMANI VOMMI
 * @version 1.16.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author hvomm
 */
public class InitialFrame extends JFrame {

    public InitialFrame() throws IOException {
        super("Nyan Cat");
        JPanel gamePanel = new JPanel();
        
        BufferedImage myPicture = ImageIO.read(new File("images/space.gif"));
        System.out.println("new image?");
        JLabel bckgdLabel = new JLabel(new ImageIcon(myPicture));
        System.out.println("trying to add to label");
        
        gamePanel.add(bckgdLabel);
        
        BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        JLabel poptart1 = new JLabel(new ImageIcon(pop1));
        System.out.println("trying to add to label");
         gamePanel.add(poptart1);
         
         add(gamePanel);
//    Image img = Toolkit.getDefaultToolkit().getImage("images/stars.PNG");
//    
//    JPanel gamePanel = new GamePanel();
//    gamePanel.setLayout( new FlowLayout() );
//    add(gamePanel);

        setSize(794, 640);
        setVisible(true);
    }

}
