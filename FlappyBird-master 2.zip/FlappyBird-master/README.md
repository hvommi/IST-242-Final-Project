## Flappy Bird

![Alt text](http://i.imgur.com/CVAJc7b.png)

## Usage

```
git clone https://github.com/stronglink/FlappyBird.git
cd FlappyBird
./run
```
