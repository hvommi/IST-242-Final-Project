
/**
 * File name: AnimationPane.java
 * Short description: creates components of the game in a panel
 * IST 242 Assignment:FINAL PROJECT
 *
 * @author HIMANI VOMMI, LIMA BUSHRA, SANJANA SHEORA
 * @version 4.26.19
 */

package View;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;


public class AnimationPane extends JPanel {
    
 
            

        
        private BufferedImage cat;
        JLabel poptart1, poptart2;
//      private Rectangle boundsTop, boundsBot;
        private int xPos = 0, yPos = 0;
        private int width, height;
        private int direction = 5;
//        private int speed = 7;
        private int points;
        Timer timer;
        boolean collision = false;
        JLabel scoreLabel;
//        private Object pop1;
        private int vSpeed = 200;
        private int gravity = 70;
        private int jumping = 200;
        private int maxyPos = 300;
    private boolean falling = false;
    private int acceleration = 400;
    
     

        public AnimationPane(JLabel sLabel) throws IOException 
        {
//            JFrame frame = new JFrame("Collision Detection");
            
            setLayout(null);
           
            //adding poptarts:
            scoreLabel = sLabel;
             BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        
        poptart1 = new JLabel(new ImageIcon(pop1));
        
        BufferedImage pop2 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        poptart2 = new JLabel(new ImageIcon(pop2));
        
        //setting size and location of poptarts: 
        
         poptart1.setBounds(new Rectangle (300, -100, 400, 400));
        poptart2.setBounds(new Rectangle (1000, 800, 400, 400));
//        cat.setBounds(new Rectangle (xPos, yPos, width, height));
   
        
  
        
        
        
//        boundsTop = new Rectangle(poptart1.X, poptart2.Y);
        
        //adding poptarts:
         add(poptart1);
         add(poptart2);
        
            //moves cat across screen
               cat = ImageIO.read(new File("images/nyancat.png"));
               
                timer = new Timer(0, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        
                        xPos += direction;
                        if (xPos + cat.getWidth() > getWidth()) {
                            
                            xPos = getWidth() - cat.getWidth();
                            direction *= -1;
                            movePops();
                            points++;
                            sLabel.setText("Points: " + points);
                            
                        } else if (xPos < 0) {
                            movePops();                            
                            xPos = 0;
                            points++;
                            direction *= -1;
                            sLabel.setText("Points: " + points);
                        }
                        repaint();
                    }

                    
                });
                
                timer.setRepeats(true);
                timer.setCoalesce(true);
                
                timer.start();
            
        }
//        public Rectangle bounds(){
//    return (new Rectangle(xPos,yPos,width,height));
//    
//}
        
    

    private int getyPos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private int getxPos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setPosition(int xPos, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

//    private void fall() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//        public Rectangle getbounds(){
//
//    
//        new Rectangle(xPos, yPos,  width, height);
//            return null;
//        
//        cat.getbounds(new Rectangle());
//}
//    
        
        
//repainting methods
        @Override
        
     
        public Dimension getPreferredSize() {
            return cat == null ? super.getPreferredSize() : new Dimension(cat.getWidth() * 1, cat.getHeight());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            g.drawImage(cat, xPos, yPos, this);

        }
//       public void getBounds(int xPos, int yPos, int width, int height){}
        
        
     //need methods for jumping and falling
      
       
       public void act(){
           fall();
       
       }
       //opt2
//       public void fall(){
//            
//           if (falling) {
//               yPos += gravity;
//              
//               if (yPos > maxyPos) yPos = maxyPos;
//           }
//       
//       }
       //opt1
        public void fall(int yPos){
            setLocation(getxPos(),getyPos()+ 200);
            int acceleration = 0;
            vSpeed = vSpeed + acceleration;
            
        }
     
     public void  movePops(){
         Random r = new Random();
          
         
//         Rectangle bounds = cat.getBounds();
         
		
                     //sets height randomly for the poptarts

          poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
          
          while (poptart1.getLocation().getY() < -100){
                poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
          }
          
            poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
            
            while (poptart2.getLocation().getY() > 800){
                poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
                
             if (Math.abs(poptart1.getLocation().getY() - poptart2.getLocation().getY()) < 500){
                  poptart1.setBounds(new Rectangle (300,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
              poptart2.setBounds(new Rectangle (1000,  100 * (r.nextInt((10 - 1) + 1) + 1), 400, 400)); 
             }
             
             
             
                poptart1.getLocation().getX();
		poptart2.getLocation().getY();
            
            
          timer.setRepeats(true);
          timer.setCoalesce(true);
                
          timer.start();
          
     
     
     
     
     
//    public int getPoints(){
//        return points;
//    }

    //*******needs method for what happens when cat "dies"!
    
   //*****needs method for collision!

      Graphics g = null;
  		Graphics2D g2d = (Graphics2D) g;
            
             if (collision)
			g2d.drawString("COLLISION", 300,100);
	}
     }

    
//           public void checkCollision() {
//		Rectangle rect1 = poptart1.getBounds();
//		Rectangle rect2 = cat.getBounds();
//                
//                
//
//		if (rect1.intersects(rect2))
//			collision = true;
//		else
//			collision = false;
//	}
private void fall() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}