/**
 * File name: $({name}.java
 * Short description:
 * IST 242 Assignment:In class
 *
 * @author HIMANI VOMMI
 * @version 1.16.19
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author hvomm
 */
public class gamePanel extends JPanel {
    NyanCat nc;
    JLabel poptart1, poptart2, c;
    AnimationPane ap;
    // Instance Variables -- define your private data
    // Constructors
    protected Image bgImage;

    public gamePanel() throws IOException {
        super();
        //setLayout(null);
        setLayout(new GridLayout(3,1));
        System.out.println("def construct");
        System.out.println("calling nc");
        
        BufferedImage pop1 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        poptart1 = new JLabel(new ImageIcon(pop1)){
        
        public Dimension getPreferredSize() {
                return new Dimension(300, 300);
            }
        };
        
        System.out.println("trying to add to label");
        add(poptart1);
       poptart1.setLocation(0, 0);
        
        BufferedImage pop2 = ImageIO.read(new File("images/poptart.png"));
        System.out.println("new image?");
        poptart2 = new JLabel(new ImageIcon(pop2)){
        public Dimension getPreferredSize() {
                return new Dimension(700, 700);
            }
        };
        System.out.println("trying to add to label");
         add(poptart2);
        
        ap = new AnimationPane();
        ap.setBackground(Color.blue);
        ap.setLocation(1500, 500);
        add(ap);
//        BufferedImage cat = ImageIO.read(new File("images/nyancat.png"));
//        System.out.println("new image?");
//        c = new JLabel(new ImageIcon(cat)){
//        public Dimension getPreferredSize() {
//                return new Dimension(1000, 1000);
//            }
//        };
//        System.out.println("trying to add to label");
//         add(c);
//         Point point = c.getLocation();
         
//         for (int i = 0; i < 5; i++){
//             point.x += 400;
//             System.out.println(point.x);
//             c.setLocation(point);
//             repaint();
//             //point.y += yDelta;
//         }

        //while (false)
        
        
        
        
        
        
        
        
    }   
    
     

    public JLabel getPoptart1() {
        return poptart1;
    }

    public JLabel getPoptart2() {
        return poptart2;
    }

    public JLabel getCat() {
        return c;
    }
    
    
    

    public gamePanel(Image image) {
        super(true);
        bgImage = image;
        setOpaque(true);
    }

    public void paint(Graphics g) {
        g.drawImage(bgImage, 0, 0, this);
        super.paint(g);
    }
//	public gamePanel()
//	{
//		 super();
     
//        
//        setBackground(Color.cyan); //background color
//        
//        System.out.println("Construct Initial Panel");
//         
}

// Set methods - one set method for each instance variable defined above
//             - purpose is to pass in a value stored in the private variable
// Get methods - one get method for each instance variable defined above
//             - purpose is to return the value stored in the private variable
// Additional methods -- such as for calculation, display





