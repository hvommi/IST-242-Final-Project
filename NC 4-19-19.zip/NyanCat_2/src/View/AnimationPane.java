
/**
	File name: $({name}.java
	Short description:
	IST 242 Assignment:In class
	@author HIMANI VOMMI
	@version 1.16.19 
*/

package View;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;






/**
 *
 * @author hvomm
 */
public class AnimationPane extends JPanel {

        private BufferedImage cat;
        private int xPos = 0;
        private int direction = 1;

        public AnimationPane() {
            try {
                cat = ImageIO.read(new File("nyancat.png"));
                Timer timer = new Timer(1, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        xPos += direction;
                        if (xPos + cat.getWidth() > getWidth()) {
                            xPos = getWidth() - cat.getWidth();
                            direction *= -1;
                        } else if (xPos < 0) {
                            xPos = 0;
                            direction *= -1;
                        }
                        repaint();
                    }

                    
                });
                timer.setRepeats(true);
                timer.setCoalesce(true);
                
                timer.start();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        @Override
        public Dimension getPreferredSize() {
            return cat == null ? super.getPreferredSize() : new Dimension(cat.getWidth() * 1, cat.getHeight());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            int y = getHeight() - cat.getHeight();
            g.drawImage(cat, xPos, y, this);

        }

    }