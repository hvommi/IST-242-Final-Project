package View;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class NyanCat {
	//global variables
	private Image nyanCat;
	private int xLoc = 0, yLoc = 0;
	
	/**
	 * Default constructor
	 */
	public NyanCat(int initialWidth, int initialHeight) {
            try {
                BufferedImage myPicture = ImageIO.read(new File("images/nyancat.png"));
            } catch (IOException ex) {
                System.out.println("couldn't get image");
                Logger.getLogger(NyanCat.class.getName()).log(Level.SEVERE, null, ex);
            }
		//nyanCat = Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("images/nyancat.png"));
                 //System.out.println("called scaleCat");
		//scaleCat(initialWidth, initialHeight);
               
	}
	
	/**
	 * Method to scale the bird sprite into the desired dimensions
	 * @param width The desired width of the flappy bird
	 * @param height The desired height of the flappy bird
	 */
	public void scaleCat(int width, int height) {
            System.out.println("width: " + width + " height: " + height);
		nyanCat = nyanCat.getScaledInstance(width, height, Image.SCALE_SMOOTH);		
	}
	
	/**
	 * Getter method for the flappyBird object.
	 * @return Image
	 */
	public Image getCat() {
		return nyanCat;
	}
	
	/**
	 * Method to obtain the width of the Bird object
	 * @return int
	 */
	public int getWidth() {
		try {
			return nyanCat.getWidth(null);
		}
		catch(Exception e) {
			return -1;
		}
	}
	
	/**
	 * Method to obtain the height of the Bird object
	 * @return int
	 */
	public int getHeight() {
		try {
			return nyanCat.getHeight(null);
		}
		catch(Exception e) {
			return -1;
		}
	}
	
	/**
	 * Method to set the x location of the Bird object
	 * @param x
	 */
	public void setX(int x) {
		xLoc = x;
	}
	
	/**
	 * Method to get the x location of the Bird object
	 * @return int
	 */
	public int getX() {
		return xLoc;
	}
	
	/**
	 * Method to set the y location of the Bird object
	 * @param y
	 */
	public void setY(int y) {
		yLoc = y;
	}
	
	/**
	 * Method to get the y location of the Bird object
	 * @return int
	 */
	public int getY() {
		return yLoc;
	}
	
	/**
	 * Method used to acquire a Rectangle that outlines the Bird's image
	 * @return Rectangle outlining the bird's position on screen
	 */
	public Rectangle getRectangle() {
		return (new Rectangle(xLoc, yLoc, nyanCat.getWidth(null), nyanCat.getHeight(null)));
	}
	
	/**
	 * Method to acquire a BufferedImage that represents the Bird's image object
	 * @return Bird's BufferedImage object
	 */
	public BufferedImage getBI() {
		BufferedImage bi = new BufferedImage(nyanCat.getWidth(null), nyanCat.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.getGraphics();
		g.drawImage(nyanCat, 0, 0, null);
		g.dispose();
		return bi;
	}
}